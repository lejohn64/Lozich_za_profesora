// Unit5.cpp
#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
#include "Unit5.h"
#include "Unit4.h"
#include "Unit4.cpp"
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm5 *Form5;
//---------------------------------------------------------------------------


__fastcall TForm5::TForm5(TComponent* Owner)
	: TForm(Owner)
{
	korisnici->Active =True;
	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form5->Font->Size=fontSize;
	Form5->Font->Name=fontName;
	LabelUnos->Font->Style=TFontStyles() << fsBold;


	delete ini;

    	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");



	Form5->Height=reg->ReadInteger("Visina");
	Form5->Width=reg->ReadInteger("Sirina");
	Form5->Top=reg->ReadInteger("Gore");
	Form5->Left=reg->ReadInteger("Lijevo");
	Form5->Color = TColor(RGB(211,211,211 ));



	reg->CloseKey();
	}

	delete reg;
}
//---------------------------------------------------------------------------
void __fastcall TForm5::odustani5Click(TObject *Sender)
{
	Hide();
	Form1->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm5::potvrdi5Click(TObject *Sender)
{
	Hide();
	TForm4* form4 = new TForm4(this);
	bool zastavaPodaciBaza = false;
	string username;

	racun.setUsername(korisnicko->Text);

	korisnici->First();
	for(int i = 0; i < korisnici->RecordCount; i++)
	{

		if (racun.getUsername() == korisnici->FieldByName("Username")->AsString)
		{
			zastavaPodaciBaza = true;
			racun.setID(korisnici->FieldByName("ID")->AsInteger);

			username = AnsiString(korisnicko->Text).c_str();
			break;
		}

		korisnici->Next();
	}
	if (zastavaPodaciBaza == false)
	{
		ShowMessage("Korisnik ne postoji");
	}
	else
	{

		form4->Show();
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm5::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------

