﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit4.h"
#include "Unit5.h"
#include <vcl.h>
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm4 *Form4;

QuestionClass promjena;



//---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner)
	: TForm(Owner)
{
	Pitanje->Active =True;
	Korisnici2->Active =True;




	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form4->Font->Size=fontSize;
	Form4->Font->Name=fontName;
	LabelMolimVas->Font->Style=TFontStyles() << fsBold;
	LabelNovaLozinka->Font->Style=TFontStyles() << fsBold;
	LabelPonovnoNova->Font->Style=TFontStyles() << fsBold;
	LabelUpute->Font->Style=TFontStyles() << fsBold;

	delete ini;


	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");
	reg->WriteBool("Checkbox",true);


	Form4->Height=reg->ReadInteger("Visina");
	Form4->Width=reg->ReadInteger("Sirina");
	Form4->Top=reg->ReadInteger("Gore");
	Form4->Left=reg->ReadInteger("Lijevo");
	Form4->Color = TColor(RGB(211,211,211 ));
	Form4->PrikazLozinke3->Checked=reg->ReadBool("Checkbox");



	reg->CloseKey();
	}

	delete reg;
}
//---------------------------------------------------------------------------
void __fastcall TForm4::Edit3Change(TObject *Sender)
{
	Korisnik korisnik(UTF8String(racun.getUsername()).c_str(), AnsiString(Edit3->Text).c_str(), True);

	ProgressBar2->Min = 0;
	ProgressBar2->Max = 4;
	if(korisnik.GetPasswordScore()=="")
		ProgressBar2->Position = 0;
	else
		ProgressBar2->Position = StrToInt(korisnik.GetPasswordScore());

	Tip4->Caption = korisnik.GetPasswordTip();

}
//---------------------------------------------------------------------------


void __fastcall TForm4::Button1Click(TObject *Sender)
{
	bool zastavaLozinka = false;
	bool zastavaPitanje = false;



	Korisnik korisnik(UTF8String(racun.getUsername()).c_str(), AnsiString(Edit3->Text).c_str(), True);


	Pitanje->First();

	for(int i = 0; i < Pitanje->RecordCount; i++) {
		if (racun.getID() == Pitanje->FieldByName("UserID")->AsInteger && promjena.GetOdgovor() == Pitanje->FieldByName("Odgovor")->AsString) {
			zastavaPitanje = true;
			break;
		}

		Pitanje->Next();
	}

	if (!zastavaPitanje) {
		ShowMessage("Odgovor nije točan!");
	}
	else {
		if (Edit3->Text != Edit4->Text) {
			ShowMessage("Lozinke se ne podudaraju");
		}
		else {
			Korisnici2->First();
			for(int i = 0; i < Korisnici2->RecordCount; i++) {

			UnicodeString nasId = racun.getID();
			UnicodeString vasId =  Korisnici2->FieldByName("ID")->Text;

				if (nasId == vasId) {
					Korisnici2->Edit();
					Korisnici2->FieldByName("Username")->AsString = korisnik.getUsername();
					Korisnici2->FieldByName("Password")->AsString = korisnik.getPassword();
					Korisnici2->Post();
					break;
				}

				Korisnici2->Next();
			}

			ShowMessage("Zapis je ažuriran!");
			Hide();
			Form1->Show();
		}
	}
}

//---------------------------------------------------------------------------

void __fastcall TForm4::Button2Click(TObject *Sender)
{
	Hide();
	Form1->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm4::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------



void __fastcall TForm4::FormShow(TObject *Sender)
{
	promjena.setPitanje(stoi(racun.getID().c_str()) , Pitanje	);
	promjena.setOdgovor(stoi(racun.getID().c_str()) , Pitanje	);
	Pitanje3->Caption = promjena.GetPitanje();
}
//---------------------------------------------------------------------------

