//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Unit6.h"
#include "Unit7.h"
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm7 *Form7;
//---------------------------------------------------------------------------
__fastcall TForm7::TForm7(TComponent* Owner)
	: TForm(Owner)
{
	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form7->Font->Size=fontSize;
	Form7->Font->Name=fontName;
	Preuzimanje->Font->Style=TFontStyles() << fsBold;


	delete ini;

	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");
	reg->WriteInteger("brzina",1);



	Form7->Height=reg->ReadInteger("Visina");
	Form7->Width=reg->ReadInteger("Sirina");
	Form7->Top=reg->ReadInteger("Gore");
	Form7->Left=reg->ReadInteger("Lijevo");
	Form7->Color = TColor(RGB(211,211,211 ));
	Form7->Brzine->ItemIndex=reg->ReadInteger("brzina");


	reg->CloseKey();
	}

	delete reg;
}

//---------------------------------------------------------------------------

void __fastcall TForm7::PreuzmiClick(TObject *Sender)
{
		UnicodeString faviconURL = "https://" + GlobalURL + "/favicon.ico";


		TMemoryStream* faviconStream = new TMemoryStream();
		IdHTTP1->Get(faviconURL, faviconStream);
		faviconStream->Position = 0;
		faviconStream->SaveToFile("favicon.ico");

		Image1->Picture->LoadFromFile("favicon.ico");
		Image1->AutoSize = true;
		Image1->Center = true;
		Image1->Proportional = true;

		delete faviconStream;
}
//---------------------------------------------------------------------------

void __fastcall TForm7::BrzineChange(TObject *Sender)
{
	IdInterceptThrottler1->BitsPerSec = StrToInt(Brzine->Text);
}
//---------------------------------------------------------------------------

void __fastcall TForm7::IdHTTP1WorkBegin(TObject *ASender, TWorkMode AWorkMode, __int64 AWorkCountMax)
{
	ProgressBar1->Position = 0;
	ProgressBar1->Max = AWorkCountMax;

}
//---------------------------------------------------------------------------

void __fastcall TForm7::IdHTTP1Work(TObject *ASender, TWorkMode AWorkMode, __int64 AWorkCount)
{
	ProgressBar1->Position = AWorkCount;
	DownloadLabel->Caption = UnicodeString((AWorkCount/ProgressBar1->Max)*100 )+ "%";
	Application->ProcessMessages();
}
//---------------------------------------------------------------------------

//


void __fastcall TForm7::BUredu7Click(TObject *Sender)
{
	Hide();
    Form6->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm7::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------

