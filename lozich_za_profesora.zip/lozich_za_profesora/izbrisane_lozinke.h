
// ********************************************************* //
//                                                         
//                    XML Data Binding                     
//                                                         
//         Generated on: 8.7.2023. 16:14:05                
//       Generated from: D:\lozich\izbrisane_lozinke.xml   
//   Settings stored in: D:\lozich\izbrisane_lozinke.xdb   
//                                                         
// ********************************************************* //

#ifndef   izbrisane_lozinkeH
#define   izbrisane_lozinkeH

#include <System.hpp>
#include <System.Variants.hpp>
#include <System.SysUtils.hpp>
#include <Xml.Xmldom.hpp>
#include <Xml.XMLIntf.hpp>
#include <Xml.XMLDoc.hpp>
#include <XMLNodeImp.h>
#include <Xml.xmlutil.hpp>


// Forward Decls 

__interface IXMLpasswordsType;
typedef System::DelphiInterface<IXMLpasswordsType> _di_IXMLpasswordsType;
__interface IXMLpasswordType;
typedef System::DelphiInterface<IXMLpasswordType> _di_IXMLpasswordType;
__interface IXMLpasswordTypeList;
typedef System::DelphiInterface<IXMLpasswordTypeList> _di_IXMLpasswordTypeList;

// IXMLpasswordsType 

__interface INTERFACE_UUID("{585C5AE6-12DF-4B21-82C5-9E38CCD9A522}") IXMLpasswordsType : public Xml::Xmlintf::IXMLNodeCollection
{
public:
public:
  // Property Accessors 
  virtual _di_IXMLpasswordType __fastcall Get_password(const int Index) = 0;
  // Methods & Properties 
  virtual _di_IXMLpasswordType __fastcall Add() = 0;
  virtual _di_IXMLpasswordType __fastcall Insert(const int Index) = 0;
  __property _di_IXMLpasswordType password[const int Index] = { read=Get_password };/* default */
};

// IXMLpasswordType 

__interface INTERFACE_UUID("{BF1DE1D9-55B3-4321-B7EF-9AA07054281A}") IXMLpasswordType : public Xml::Xmlintf::IXMLNode
{
public:
  // Property Accessors 
  virtual int __fastcall Get_id() = 0;
  virtual System::AnsiString __fastcall Get_master_username() = 0;
  virtual System::UnicodeString __fastcall Get_title() = 0;
  virtual System::UnicodeString __fastcall Get_username() = 0;
  virtual System::UnicodeString __fastcall Get_password() = 0;
  virtual System::UnicodeString __fastcall Get_timestamp() = 0;
  virtual void __fastcall Set_id(const int Value) = 0;
  virtual void __fastcall Set_master_username(const System::AnsiString Value) = 0;
  virtual void __fastcall Set_title(const System::UnicodeString Value) = 0;
  virtual void __fastcall Set_username(const System::UnicodeString Value) = 0;
  virtual void __fastcall Set_password(const System::UnicodeString Value) = 0;
  virtual void __fastcall Set_timestamp(const System::UnicodeString Value) = 0;
  // Methods & Properties 
  __property int id = { read=Get_id, write=Set_id };
  __property System::AnsiString master_username = { read=Get_master_username, write=Set_master_username };
  __property System::UnicodeString title = { read=Get_title, write=Set_title };
  __property System::UnicodeString username = { read=Get_username, write=Set_username };
  __property System::UnicodeString password = { read=Get_password, write=Set_password };
  __property System::UnicodeString timestamp = { read=Get_timestamp, write=Set_timestamp };
};

// IXMLpasswordTypeList 

__interface INTERFACE_UUID("{39C24456-A247-47DB-8012-47CD55815B5B}") IXMLpasswordTypeList : public Xml::Xmlintf::IXMLNodeCollection
{
public:
  // Methods & Properties 
  virtual _di_IXMLpasswordType __fastcall Add() = 0;
  virtual _di_IXMLpasswordType __fastcall Insert(const int Index) = 0;

  virtual _di_IXMLpasswordType __fastcall Get_Item(const int Index) = 0;
  __property _di_IXMLpasswordType Items[const int Index] = { read=Get_Item /* default */ };
};

// Forward Decls 

class TXMLpasswordsType;
class TXMLpasswordType;
class TXMLpasswordTypeList;

// TXMLpasswordsType 

class TXMLpasswordsType : public Xml::Xmldoc::TXMLNodeCollection, public IXMLpasswordsType
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLpasswordsType 
  virtual _di_IXMLpasswordType __fastcall Get_password(const int Index);
  virtual _di_IXMLpasswordType __fastcall Add();
  virtual _di_IXMLpasswordType __fastcall Insert(const int Index);
public:
  virtual void __fastcall AfterConstruction(void);
};

// TXMLpasswordType 

class TXMLpasswordType : public Xml::Xmldoc::TXMLNode, public IXMLpasswordType
{
  __IXMLNODE_IMPL__
protected:
  // IXMLpasswordType 
  virtual int __fastcall Get_id();
  virtual System::AnsiString __fastcall Get_master_username();
  virtual System::UnicodeString __fastcall Get_title();
  virtual System::UnicodeString __fastcall Get_username();
  virtual System::UnicodeString __fastcall Get_password();
  virtual System::UnicodeString __fastcall Get_timestamp();
  virtual void __fastcall Set_id(const int Value);
  virtual void __fastcall Set_master_username(const System::AnsiString Value);
  virtual void __fastcall Set_title(const System::UnicodeString Value);
  virtual void __fastcall Set_username(const System::UnicodeString Value);
  virtual void __fastcall Set_password(const System::UnicodeString Value);
  virtual void __fastcall Set_timestamp(const System::UnicodeString Value);
};

// TXMLpasswordTypeList 

class TXMLpasswordTypeList : public Xml::Xmldoc::TXMLNodeCollection, public IXMLpasswordTypeList
{
  __IXMLNODECOLLECTION_IMPL__
protected:
  // IXMLpasswordTypeList 
  virtual _di_IXMLpasswordType __fastcall Add();
  virtual _di_IXMLpasswordType __fastcall Insert(const int Index);

  virtual _di_IXMLpasswordType __fastcall Get_Item(const int Index);
};

// Global Functions 

_di_IXMLpasswordsType __fastcall Getpasswords(Xml::Xmlintf::_di_IXMLDocument Doc);
_di_IXMLpasswordsType __fastcall Getpasswords(Xml::Xmldoc::TXMLDocument *Doc);
_di_IXMLpasswordsType __fastcall Loadpasswords(const System::UnicodeString& FileName);
_di_IXMLpasswordsType __fastcall  Newpasswords();

#define TargetNamespace ""

#endif