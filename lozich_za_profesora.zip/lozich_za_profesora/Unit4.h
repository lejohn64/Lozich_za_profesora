//---------------------------------------------------------------------------

#ifndef Unit4H
#define Unit4H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
//---------------------------------------------------------------------------
class TForm4 : public TForm
{
__published:	// IDE-managed Components
	TLabel *LabelMolimVas;
	TLabel *Pitanje3;
	TEdit *Edit2;
	TLabel *LabelNovaLozinka;
	TEdit *Edit3;
	TLabel *LabelPonovnoNova;
	TEdit *Edit4;
	TProgressBar *ProgressBar2;
	TButton *Button1;
	TButton *Button2;
	TLabel *Tip4;
	TLabel *LabelUpute;
	TCheckBox *PrikazLozinke3;
	TADOTable *Pitanje;
	TADOTable *Korisnici2;
	void __fastcall Edit3Change(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm4(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm4 *Form4;
class QuestionClass {
private:
	AnsiString Pitanje;
	AnsiString Odgovor;

public:
	QuestionClass(){}

	void setPitanje(int id,TADOTable* Question) {
		Question->First();
		for (int i = 0; i < Question->RecordCount; i++) {
		int bazaID = Question->FieldByName("UserID")->AsInteger;
			if (id == bazaID) {
				Pitanje = Question->FieldByName("Pitanje")->AsString;
			}
			Question->Next();
		}
	}

		void setOdgovor(int id,TADOTable* Question) {
		Question->First();
		for (int i = 0; i < Question->RecordCount; i++) {
		int bazaID = Question->FieldByName("UserID")->AsInteger;
			if (id == bazaID) {
				Odgovor = Question->FieldByName("Odgovor")->AsString;
			}
			Question->Next();
		}
	}

	AnsiString GetPitanje(){
		return Pitanje;
	}

		AnsiString GetOdgovor(){
		return Odgovor;
	}

};
//---------------------------------------------------------------------------
extern QuestionClass promjena;
#endif
