#include "User_i_ID.h"

	UnicodeString UsernameID::getID(){
		return ID;
	}

	UnicodeString UsernameID::getUsername(){
		return Username;
	}

	void UsernameID::setID(UnicodeString _ID){
		ID= _ID;
	}

	void UsernameID::setUsername(UnicodeString username){
		Username= username;
	}

	bool UsernameID::validUsername(UnicodeString _username){
		return _username.IsEmpty();
	}
