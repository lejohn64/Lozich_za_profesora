const express = require('express');
const cors = require('cors');
const zxcvbn = require('zxcvbn');

const app = express();

app.use(cors());
app.use(express.json());

app.post('/passwordCheck', (req, res) => {
  const { username, password } = req.body;

  // Check if username or password is missing
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const result = zxcvbn(password, [username]);

  // Send back the score and some suggestions for improving password strength
  res.json({ score: result.score, suggestions: result.feedback.suggestions });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on port ${port}`));
