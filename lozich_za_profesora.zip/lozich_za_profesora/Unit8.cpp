//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit8.h"
#include "Unit2.h"
#include "Unit1.h"
#include "izbrisane_lozinke.h"
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm8 *Form8;
//---------------------------------------------------------------------------
__fastcall TForm8::TForm8(TComponent* Owner)
	: TForm(Owner)
{
  	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form8->Font->Size=fontSize;
	Form8->Font->Name=fontName;

	delete ini;

	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");




	Form8->Height=reg->ReadInteger("Visina");
	Form8->Width=reg->ReadInteger("Sirina");
	Form8->Top=reg->ReadInteger("Gore");
	Form8->Left=reg->ReadInteger("Lijevo");
	Form8->Color = TColor(RGB(211,211,211 ));



	reg->CloseKey();
	}

	delete reg;
}

//---------------------------------------------------------------------------
void __fastcall TForm8::Povratak8Click(TObject *Sender)
{
	Hide();
    Aplikacija->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm8::Prikaz8Click(TObject *Sender)
{
	_di_IXMLpasswordsType lozinke = Getpasswords(XMLDocument1);

	ListView1->Items->Clear();
	int j=0;
	for(int i=0;i<lozinke->Count;i++){

		if(lozinke->password[i]->id == racun.getID()){

			ListView1->Items->Add();
			ListView1->Items->Item[j]->Caption = lozinke->password[i]->id;
            ListView1->Items->Item[j]->SubItems->Add(lozinke->password[i]->master_username);
			ListView1->Items->Item[j]->SubItems->Add(lozinke->password[i]->title);
			ListView1->Items->Item[j]->SubItems->Add(lozinke->password[i]->username);
			ListView1->Items->Item[j]->SubItems->Add(lozinke->password[i]->password);
			ListView1->Items->Item[j]->SubItems->Add(lozinke->password[i]->timestamp);
			j++;
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm8::Delete8Click(TObject *Sender)
{
	_di_IXMLpasswordsType lozinke = Getpasswords(XMLDocument1);
	for(int i = lozinke->Count - 1; i >= 0; i--){
		if(lozinke->password[i]->id == racun.getID()){

			lozinke->Delete(i);

		}
	}
	XMLDocument1->SaveToFile(XMLDocument1->FileName);


	TCP_klijent->Host = "127.0.0.1";
	TCP_klijent->Port = 6969;
	TCP_klijent->Connect();
	TCP_klijent->IOHandler->WriteLn("Dodaj");


	std::unique_ptr<TFileStream> fs(new TFileStream(XMLDocument1->FileName, fmOpenRead));
	TCP_klijent->Socket->WriteLn(ExtractFileName(fs->FileName));
	TCP_klijent->Socket->Write(fs->Size);
	TCP_klijent->Socket->Write(fs.get());




  TCP_klijent->Disconnect();
}
//---------------------------------------------------------------------------

void __fastcall TForm8::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------

