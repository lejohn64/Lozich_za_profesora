// ********************************************************* //
//                                                         
//                    XML Data Binding                     
//                                                         
//         Generated on: 8.7.2023. 16:14:05                
//       Generated from: D:\lozich\izbrisane_lozinke.xml   
//   Settings stored in: D:\lozich\izbrisane_lozinke.xdb   
//                                                         
// ********************************************************* //

#include <System.hpp>
#pragma hdrstop

#include "izbrisane_lozinke.h"


// Global Functions 

_di_IXMLpasswordsType __fastcall Getpasswords(Xml::Xmlintf::_di_IXMLDocument Doc)
{
  return (_di_IXMLpasswordsType) Doc->GetDocBinding("passwords", __classid(TXMLpasswordsType), TargetNamespace);
};

_di_IXMLpasswordsType __fastcall Getpasswords(Xml::Xmldoc::TXMLDocument *Doc)
{
  Xml::Xmlintf::_di_IXMLDocument DocIntf;
  Doc->GetInterface(DocIntf);
  return Getpasswords(DocIntf);
};

_di_IXMLpasswordsType __fastcall Loadpasswords(const System::UnicodeString& FileName)
{
  return (_di_IXMLpasswordsType) Xml::Xmldoc::LoadXMLDocument(FileName)->GetDocBinding("passwords", __classid(TXMLpasswordsType), TargetNamespace);
};

_di_IXMLpasswordsType __fastcall  Newpasswords()
{
  return (_di_IXMLpasswordsType) Xml::Xmldoc::NewXMLDocument()->GetDocBinding("passwords", __classid(TXMLpasswordsType), TargetNamespace);
};

// TXMLpasswordsType 

void __fastcall TXMLpasswordsType::AfterConstruction(void)
{
  RegisterChildNode(System::UnicodeString("password"), __classid(TXMLpasswordType));
  ItemTag = "password";
  ItemInterface = __uuidof(IXMLpasswordType);
  Xml::Xmldoc::TXMLNodeCollection::AfterConstruction();
};

_di_IXMLpasswordType __fastcall TXMLpasswordsType::Get_password(const int Index)
{
  return (_di_IXMLpasswordType) List->Nodes[Index];
};

_di_IXMLpasswordType __fastcall TXMLpasswordsType::Add()
{
  return (_di_IXMLpasswordType) AddItem(-1);
};

_di_IXMLpasswordType __fastcall TXMLpasswordsType::Insert(const int Index)
{
  return (_di_IXMLpasswordType) AddItem(Index);
};

// TXMLpasswordType 

int __fastcall TXMLpasswordType::Get_id()
{
  return XmlStrToInt(GetChildNodes()->Nodes[System::UnicodeString("id")]->Text);
};

void __fastcall TXMLpasswordType::Set_id(const int Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("id")]->NodeValue = Value;
};

System::AnsiString __fastcall TXMLpasswordType::Get_master_username()
{
  return GetChildNodes()->Nodes[System::UnicodeString("master_username")]->Text;
};

void __fastcall TXMLpasswordType::Set_master_username(const System::AnsiString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("master_username")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLpasswordType::Get_title()
{
  return GetChildNodes()->Nodes[System::UnicodeString("title")]->Text;
};

void __fastcall TXMLpasswordType::Set_title(const System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("title")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLpasswordType::Get_username()
{
  return GetChildNodes()->Nodes[System::UnicodeString("username")]->Text;
};

void __fastcall TXMLpasswordType::Set_username(const System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("username")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLpasswordType::Get_password()
{
  return GetChildNodes()->Nodes[System::UnicodeString("password")]->Text;
};

void __fastcall TXMLpasswordType::Set_password(const System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("password")]->NodeValue = Value;
};

System::UnicodeString __fastcall TXMLpasswordType::Get_timestamp()
{
  return GetChildNodes()->Nodes[System::UnicodeString("timestamp")]->Text;
};

void __fastcall TXMLpasswordType::Set_timestamp(const System::UnicodeString Value)
{
  GetChildNodes()->Nodes[System::UnicodeString("timestamp")]->NodeValue = Value;
};

// TXMLpasswordTypeList 

_di_IXMLpasswordType __fastcall TXMLpasswordTypeList::Add()
{
  return (_di_IXMLpasswordType) AddItem(-1);
};

_di_IXMLpasswordType __fastcall TXMLpasswordTypeList::Insert(const int Index)
{
  return (_di_IXMLpasswordType) AddItem(Index);
};

_di_IXMLpasswordType __fastcall TXMLpasswordTypeList::Get_Item(const int Index)
{
  return (_di_IXMLpasswordType) List->Nodes[Index];
};
