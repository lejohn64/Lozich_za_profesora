//---------------------------------------------------------------------------

#ifndef Uint3H
#define Uint3H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <Vcl.ComCtrls.hpp>
//---------------------------------------------------------------------------
class TRegistracija : public TForm
{
__published:	// IDE-managed Components
	TLabel *LKorisnicko2;
	TEdit *EKorisnickoReg;
	TLabel *LozinkaLabel;
	TEdit *ELozinkaReg;
	TLabel *LozinkaPonovi;
	TEdit *ELozinka2Reg;
	TButton *Gumb;
	TADOTable *Korisnici2;
	TButton *Povratak10;
	TCheckBox *PrikazLozinke2;
	TProgressBar *ProgressBar2;
	TLabel *Tip3;
	TLabel *LUpute;
	TADOTable *Pitanje;
	TComboBox *ComboBox1;
	TLabel *Lpitanje;
	TLabel *LOdgovor;
	TEdit *Edit1;
	void __fastcall GumbClick(TObject *Sender);
	void __fastcall Povratak10Click(TObject *Sender);
	void __fastcall PrikazLozinke2Click(TObject *Sender);
	void __fastcall ELozinkaRegChange(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
public:		// User declarations
	__fastcall TRegistracija(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TRegistracija *Registracija;
//---------------------------------------------------------------------------
#endif
