//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
#include "Unit3.h"
#include <registry.hpp>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRegistracija *Registracija;


//---------------------------------------------------------------------------
void __fastcall TRegistracija::PrikazLozinke2Click(TObject *Sender)
{
   if (PrikazLozinke2->Checked == False) {
	  ELozinkaReg->PasswordChar = '*';
	  ELozinka2Reg->PasswordChar = '*';
   }

   else{
	  ELozinkaReg->PasswordChar = 0;
	  ELozinka2Reg->PasswordChar = 0;
   }
}
//---------------------------------------------------------------------------
__fastcall TRegistracija::TRegistracija(TComponent* Owner)
	: TForm(Owner)
{
	ELozinkaReg->PasswordChar = '*';
	ELozinka2Reg->PasswordChar = '*';

	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Registracija->Font->Size=fontSize;
	Registracija->Font->Name=fontName;
	LKorisnicko2->Font->Style=TFontStyles() << fsBold;
	Lpitanje->Font->Style=TFontStyles() << fsBold;
	LOdgovor->Font->Style=TFontStyles() << fsBold;
	LozinkaLabel->Font->Style=TFontStyles() << fsBold;
	LozinkaPonovi->Font->Style=TFontStyles() << fsBold;
	LUpute->Font->Style=TFontStyles() << fsBold;

	delete ini;

	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");


	reg->WriteString("Odgovor",".....");

	Registracija->Height=reg->ReadInteger("Visina");
	Registracija->Width=reg->ReadInteger("Sirina");
	Registracija->Top=reg->ReadInteger("Gore");
	Registracija->Left=reg->ReadInteger("Lijevo");
	Registracija->Color = TColor(RGB(211,211,211 ));

	Registracija->Edit1->TextHint=reg->ReadString("Odgovor");


	reg->CloseKey();
	}

	delete reg;
}
//---------------------------------------------------------------------------
void __fastcall TRegistracija::GumbClick(TObject *Sender)
{
int maxID = 0;
bool zastavaLozinka=False;
bool zastavaPodaciBaza=False;

Korisnik korisnik (AnsiString(EKorisnickoReg->Text).c_str(), AnsiString(ELozinkaReg->Text).c_str(), True);

if (ELozinkaReg->Text == ELozinka2Reg->Text) {
	 zastavaLozinka=True;
}

Korisnici2->First();
	//provjera ID-a za pitanja
   for(int i=0;i<Korisnici2->RecordCount;i++)
   {
	  maxID = Korisnici2->FieldByName("ID")->AsInteger;
	  Korisnici2->Next();
   }

 Korisnici2->First();
 	//provjera korisnika u bazi za registraciju
   for(int i=0;i<Korisnici2->RecordCount;i++)
   {
	  if ((korisnik.getUsername() == Korisnici2->FieldByName("Username")->AsString)) {
	  zastavaPodaciBaza = True;
	  maxID = Korisnici2->FieldByName("ID")->AsInteger;
	  break;
	  }

	  Korisnici2->Next();
   }

   if (zastavaPodaciBaza==True) {
		ShowMessage("Korisnik vec postoji");
   }

   else {

	   if (zastavaLozinka==False) {
			  ShowMessage("lozinke se ne podudaraju");
	   }

	   else{
			if(korisnik.GetPasswordScore().ToInt()<=2){
				ShowMessage("Koristite sigurniju lozinku!");
			}

			else{
				Korisnici2->Append();
				Korisnici2->FieldByName("Username")->AsString = korisnik.getUsername();
				Korisnici2->FieldByName("Password")->AsString = korisnik.getPassword();
				Korisnici2->Post();

				Pitanje->Append();
				Pitanje->FieldByName("UserID")->AsLargeInt = maxID + 1;
				Pitanje->FieldByName("Pitanje")->AsString = ComboBox1->Text;
				Pitanje->FieldByName("Odgovor")->AsString = Edit1->Text;
				Pitanje->Post();
				Hide();
				Form1->Show();
			}
	   }
   }

}
//---------------------------------------------------------------------------

void __fastcall TRegistracija::Povratak10Click(TObject *Sender)
{
  Hide();
  Form1->Show();
}
//---------------------------------------------------------------------------

void __fastcall TRegistracija::ELozinkaRegChange(TObject *Sender)
{
	Korisnik korisnik(AnsiString(EKorisnickoReg->Text).c_str(), AnsiString(ELozinkaReg->Text).c_str(), True);

	ProgressBar2->Min = 0;
	ProgressBar2->Max = 4;
	if(korisnik.GetPasswordScore()=="")
		ProgressBar2->Position = 0;
	else
		ProgressBar2->Position = StrToInt(korisnik.GetPasswordScore());

	Tip3->Caption = korisnik.GetPasswordTip();
}
//---------------------------------------------------------------------------


void __fastcall TRegistracija::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------


