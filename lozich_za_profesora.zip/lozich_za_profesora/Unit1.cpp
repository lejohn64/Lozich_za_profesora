﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
#include "Unit5.h"
#include "Unit6.h"
#include "Unit7.h"
#include "Unit8.h"
#include "Unit9.h"
#include "Unit10.h"
#include <registry.hpp>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Hash"
#pragma link "uTPLb_Signatory"
#pragma link "uTPLb_Codec"
#pragma resource "*.dfm"
void translateForm(TForm* Form, String Language, const std::map<String, std::map<String,String>>& translation){
for (int i=0;i<Form->ComponentCount;i++)
	for(auto it_ComponentName=translation.begin();it_ComponentName != translation.end();it_ComponentName++)
		if(Form->Components[i]->Name == it_ComponentName->first)
		  for (auto it_Language = it_ComponentName->second.begin();it_Language !=it_ComponentName->second.end();it_Language++)
		  if(it_Language->first == Language)
			 if(IsPublishedProp(Form->Components[i],"Caption"))
				 SetPropValue(Form->Components[i],"Caption",it_Language->second);
}
TForm1 *Form1;
using namespace std;
//---------------------------------------------------------------------------
UsernameID racun;

__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
	EditLozinka->PasswordChar = '*';
	ADOConnection1->Connected = True;
	tablica_korisnika->Active = True;


    HINSTANCE RecourceDll;

	if ((RecourceDll = LoadLibrary(L"Logotip.dll")) == NULL) {
		ShowMessage("Can't load DLL");
		return;
	}
	TResourceStream* rs = new TResourceStream((int)RecourceDll, "LOGO", RT_RCDATA);
	Image1->Picture->LoadFromStream(rs);
	delete rs;
	FreeLibrary(RecourceDll);


	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form1->Font->Size = fontSize;
	Form1->Font->Name = fontName;

	Label1->Font->Style = TFontStyles() << fsBold;
	Label2->Font->Style = TFontStyles() << fsBold;

	delete ini;

    TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");

	reg->WriteInteger("FontSize",10);

	Form1->Height=reg->ReadInteger("Visina");
	Form1->Width=reg->ReadInteger("Sirina");
	Form1->Top=reg->ReadInteger("Gore");
	Form1->Left=reg->ReadInteger("Lijevo");
	Form1->Color = TColor(RGB(211,211,211 ));
	reg->CloseKey();
	}

	delete reg;


    translation ["Label1"] = {

{
	{"EN","Username:"},
	{"HR","Korisničko ime:"}
}

};

translation ["Label2"] = {

{
	{"EN","Password:"},
	{"HR","Lozinka:"}
}

};

translation ["Prijava"] = {

{
	{"EN","Login"},
	{"HR","Prijava"}
}

};


translation ["Prijevod"] = {

{
	{"EN","Translate"},
	{"HR","Prijevod"}
}

};

translation ["Label3"] = {

{
	{"EN","Forgot your password?"},
	{"HR","Zaboravili ste lozinku?"}
}

};

translation ["PrikazLozinke"] = {

{
	{"EN","Show password"},
	{"HR","Prikaži lozinku"}
}

};

translation ["PrikazLozinke2"] = {

{
	{"EN","Show password"},
	{"HR","Prikaži lozinku"}
}

};

translation ["PrikazLozinke3"] = {

{
	{"EN","Show password"},
	{"HR","Prikaži lozinku"}
}

};

translation ["LNaslov"] = {

{
	{"EN","Title"},
	{"HR","Naslov"}
}

};

translation ["LKorisnik"] = {

{
	{"EN","User"},
	{"HR","Korisnik"}
}

};

translation ["LSifra"] = {

{
	{"EN","Password"},
	{"HR","Lozinka"}
}

};
translation ["Lpitanje"] = {

{
	{"EN","Security question"},
	{"HR","Sigurnosno pitanje"}
}

};

translation ["LBiljeske"] = {

{
	{"EN","Notes"},
	{"HR","Bilješke"}
}

};

translation ["Button8"] = {

{
	{"EN","Change record"},
	{"HR","Promijeni zapis"}
}

};

translation ["Button1"] = {

{
	{"EN","Generate password"},
	{"HR","Generiraj lozinku"}
}

};

translation ["Button6"] = {

{
	{"EN","Open deleted passwords"},
	{"HR","Otvori izbrisane lozinke"}
}

};

translation ["Button5"] = {

{
	{"EN","Delete selected password"},
	{"HR","Izbriši označenu lozinku"}
}

};

translation ["Button9"] = {

{
	{"EN","Login History"},
	{"HR","Povijest loginova"}
}

};
translation ["Button2"] = {

{
	{"EN","Show report"},
	{"HR","Prikaži ispis"}
}

};
translation ["Button3"] = {

{
	{"EN","Generate PDF"},
	{"HR","Generiraj PDF"}
}

};
translation ["Button4"] = {

{
	{"EN","Generate RTF"},
	{"HR","Generiraj RTF"}
}

};
translation ["Button7"] = {

{
	{"EN","Change"},
	{"HR","Promijena"}
}

};

translation ["PrikazLozinki"] = {

{
	{"EN","Show"},
	{"HR","Prikaz"}
}

};

translation ["Sort"] = {

{
	{"EN","Sort"},
	{"HR","Sortiraj"}
}

};

translation ["Uredu"] = {

{
	{"EN","Ok"},
	{"HR","Uredu"}
}

};
translation ["Korisnik"] = {

{
	{"EN","User"},
	{"HR","Korisnik"}
}

};
translation ["Naslov"] = {

{
	{"EN","Title"},
	{"HR","Naslov"}
}

};

translation ["Korisnik2"] = {

{
	{"EN","User"},
	{"HR","Korisnik"}
}

};
translation ["Naslov2"] = {

{
	{"EN","Title"},
	{"HR","Naslov"}
}

};
translation ["ASC"] = {

{
	{"EN","ascending"},
	{"HR","uzlazno"}
}

};
translation ["DESC"] = {

{
	{"EN","descending"},
	{"HR","silazno"}
}

};
translation ["GroupBox1"] = {

{
	{"EN","Field for sort"},
	{"HR","Polje za sortiranje"}
}

};
translation ["GroupBox2"] = {

{
	{"EN","Sort direction"},
	{"HR","Smjer sortiranja"}
}

};

 translation ["GroupBox3"] = {

{
	{"EN","Field to filter"},
	{"HR","Polje za filtriranje"}
}

};

translation ["otvori_reg"] = {

{
	{"EN","Registration"},
	{"HR","Registracija"}
}
};

translation ["LKorisnicko2"] = {

{
	{"EN","Username"},
	{"HR","Korisničko ime"}
}
};

translation ["LPitanje"] = {

{
	{"EN","Safe question"},
	{"HR","igurnosno pitanje"}
}
};

translation ["LOdgovor"] = {

{
	{"EN","answer"},
	{"HR","Odgovor"}
}
};

translation ["LozinkaLabel"] = {

{
	{"EN","Password"},
	{"HR","Lozinka"}
}
};

translation ["LozinkaPonovi"] = {

{
	{"EN","Show password"},
	{"HR","Ponovi lozinku"}
}
};
translation ["LUpute"] = {

{
	{"EN","Instructions for safer password"},
	{"HR","Upute za sigurniju lozinku"}
}
};

translation ["PrikazLozinki2"] = {

{
	{"EN","Show password"},
	{"HR","Prikazi lozinku"}
}
};
translation ["LabelUnos"] = {

{
	{"EN","Insert username"},
	{"HR","Unesite korisnicko ime"}
}
};
translation ["LNaslov6"] = {

{
	{"EN","Title"},
	{"HR","Naslov"}
}
};
translation ["LKorisnicko6"] = {

{
	{"EN","Insert username"},
	{"HR","Unesite korisnicko ime"}
}
};
translation ["LLozinka6"] = {

{
	{"EN","password"},
	{"HR","lozinka"}
}
};
translation ["LBiljeske"] = {

{
	{"EN","Notes"},
	{"HR","Biljeske"}
}
};
translation ["LPostavke6"] = {

{
	{"EN","Settings"},
	{"HR","Postavke"}
}
};
translation ["BZapis"] = {

{
	{"EN","Record"},
	{"HR","Zapis"}
}
};
translation ["BPovratak"] = {

{
	{"EN","Back"},
	{"HR","Povratak"}
}
};
translation ["BGeneriraj"] = {

{
	{"EN","Generate"},
	{"HR","Generiraj"}
}
};
translation ["Preuzimanje"] = {

{
	{"EN","Downloading"},
	{"HR","Preuzimanje"}
}
};
translation ["Preuzmi"] = {

{
	{"EN","Download"},
	{"HR","Preuzmi"}
}
};
translation ["Brzine"] = {

{
	{"EN","Speed"},
	{"HR","Brzine"}
}
};
translation ["BUredu7"] = {

{
	{"EN","Ok"},
	{"HR","Uredu"}
}
};
translation ["Povratak8"] = {

{
	{"EN","Back"},
	{"HR","Povrtak"}
}
};
translation ["Prikaz8"] = {

{
	{"EN","Show password"},
	{"HR","Prikaz lozinke"}
}
};
translation ["Delete8"] = {

{
	{"EN","Delete"},
	{"HR","Izbriši"}
}
};
translation ["Povratak10"] = {

{
	{"EN","Back"},
	{"HR","Povrtak"}
}
};
translation ["Prikaz10"] = {

{
	{"EN","Show password"},
	{"HR","Prikaz lozinke"}
}
};
translation ["Delete10"] = {
{
	{"EN","Delete"},
	{"HR","Izbriši"}
}
};

translation ["potvrdi5"] = {
{
	{"EN","Confirm"},
	{"HR","Potvrdi"}
}
};

translation ["odustani5"] = {
{
	{"EN","Cancel"},
	{"HR","Odustani"}
}
};

translation ["LabelMolimVas"] = {
{
	{"EN","Answer the question below"},
	{"HR","Odgovorite na pitanje"}
}
};

translation ["LabelNovaLozinka"] = {
{
	{"EN","Enter your password"},
	{"HR","unesite lozinku"}
}
};

translation ["LabelPonovoNova"] = {
{
	{"EN","Enter your password again"},
	{"HR","Ponovo unesite lozinku"}
}
};

translation ["LLozinkaP"] = {
{
	{"EN","Password generation settings"},
	{"HR","Postavke generiranja lozinke"}
}
};

translation ["PromijeniK9"] = {
{
	{"EN","Enter"},
	{"HR","Unesi"}
}
};

translation ["PromijeniP9"] = {
{
	{"EN","Enter"},
	{"HR","Unesi"}
}
};

translation ["IzbrisiK9"] = {
{
	{"EN","Delete user"},
	{"HR","Izbrisi korisnika"}
}
};

translation ["IzbrisiP"] = {
{
	{"EN","Delete question and answer"},
	{"HR","Izbrisi pitanje i odgovor"}
}
};
translation ["IzbrisiP9"] = {
{
	{"EN","Delete question and answer"},
	{"HR","Izbrisi pitanje i odgovor"}
}
};

translation ["korisnik9"] = {
{
	{"EN","Change username"},
	{"HR","Promjeni korisničko ime"}
}
};
translation ["Lozinka9"] = {
{
	{"EN","Change password"},
	{"HR","Promjeni lozinku"}
}
};

translation ["Nazad9"] = {
{
	{"EN","Return"},
	{"HR","Povratak"}
}
};

translation ["PitanjeOdg9"] = {
{
	{"EN","Change Question and answer"},
	{"HR","Promijeni pitanje i odgovor"}
}
};

translation ["GenIkona"] = {
{
	{"EN","Generate icon"},
	{"HR","Generiraj ikonu"}
}
};

translation ["BZapis"] = {
{
	{"EN","Confirm"},
	{"HR","Potvrdi"}
}
};
}


//---------------------------------------------------------------------------
void __fastcall TForm1::PrijavaClick(TObject *Sender)
{
   Korisnik korisnik (AnsiString(EditKorisnicko->Text).c_str(), AnsiString(EditLozinka->Text).c_str(), False);

   tablica_korisnika->Open();
   tablica_korisnika->First();
   bool zastava = False;
   for(int i=0;i<=tablica_korisnika->RecordCount;i++)
   {
	TIdHashSHA1* sha1 = new TIdHashSHA1;

	for(int i=0;i<sizeof(characters);i++){
		AnsiString pass= sha1->HashStringAsHex(AnsiString(korisnik.dobiSol().c_str()) + AnsiString(korisnik.getPassword().c_str()) + characters[i]);

		if((tablica_korisnika->FieldByName("Username")->AsString == korisnik.getUsername()) && (tablica_korisnika->FieldByName("Password")->AsString == AnsiString(pass.c_str()	)))
		{
		zastava = True;
		racun.setID(tablica_korisnika->FieldByName("ID")->AsInteger);
		racun.setUsername(tablica_korisnika->FieldByName("Username")->AsString);

		break;
		}
		
		pass=NULL;
	}
	delete sha1;
	tablica_korisnika->Next();
   }

	tablica_korisnika->Close();

   if(racun.validUsername(EditKorisnicko->Text.c_str())!= True){

  String attempt;
	 if (zastava==True) {

	 attempt="successful";
   }
   else  attempt="unsuccessful";


   String jsonDoc;
	jsonDoc = "{";
		jsonDoc += "\"logins\":";
		jsonDoc += "[";

			// load json file
	std::unique_ptr<TStringStream> jsonStream(new TStringStream);
	jsonStream->LoadFromFile("login_log.json");

	// create JSON object that represents entire JSON file
	TJSONObject* jsonFile = (TJSONObject*)TJSONObject::ParseJSONValue(jsonStream->DataString);

	// create JSON object that represent array from inside addresBook object
	TJSONArray* contactsArray = (TJSONArray*)TJSONObject::ParseJSONValue(jsonFile->GetValue("logins")->ToString());


	for (int i = 0; i < contactsArray->Count; i++) {
		// read contact info
		UnicodeString user = contactsArray->Items[i]->GetValue<UnicodeString>("user");
		UnicodeString login_attempt = contactsArray->Items[i]->GetValue<UnicodeString>("login_attempt");
		UnicodeString time =	contactsArray->Items[i]->GetValue<UnicodeString>("time");


			jsonDoc +=
			"{"
				"\"user\":\"" + user + "\"," +
				"\"login_attempt\":\"" +login_attempt  + "\"," +
				"\"time\":\"" + time + "\"" +
			"},";
	}

	Codec1->Password = "kljuc";

	UnicodeString encodedUser,encodedLogin,encodedTime;
	Codec1->EncryptString(EditKorisnicko->Text, encodedUser, TEncoding::UTF8);
	Codec1->EncryptString(attempt, encodedLogin,TEncoding::UTF8);
	Codec1->EncryptString(DateTimeToStr(Now()), encodedTime, TEncoding::UTF8);

		jsonDoc +=
			"{"
				"\"user\":\"" + encodedUser + "\"," +
				"\"login_attempt\":\"" + encodedLogin + "\"," +
				"\"time\":\"" + encodedTime + "\"" +
			"}";

		jsonDoc += "]";
	jsonDoc += "}";

	//Application->MessageBoxW(jsonDoc.w_str(), L"", 0);
	// format json document (line breaks, indents..)


	std::unique_ptr<TStringStream> ss(new TStringStream);
	ss->WriteString(jsonDoc);
	ss->SaveToFile("login_log.json");


   }

   if (zastava==True) {
	Hide();
	Aplikacija->Show();
   }
   else ShowMessage("Krivo uneseni podaci");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::otvori_regClick(TObject *Sender)
{

  Hide();
  Registracija->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::PrikazLozinkeClick(TObject *Sender)
{
   if (PrikazLozinke->Checked == False) {
	  EditLozinka->PasswordChar = '*';
   }

   else{
	  EditLozinka->PasswordChar = 0;
   }
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

void __fastcall TForm1::Label3Click(TObject *Sender)
{
	Hide();
    Form5->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton2Click(TObject *Sender)
{
  String jezik="EN";
	translateForm(this, jezik ,translation);
	translateForm(Aplikacija, jezik ,translation);
	translateForm(Registracija, jezik ,translation);
	translateForm(Form4, jezik ,translation);
	translateForm(Form5, jezik ,translation);
	translateForm(Form6, jezik ,translation);
	translateForm(Form7, jezik ,translation);
	translateForm(Form8, jezik ,translation);
	translateForm(Form9, jezik ,translation);
	translateForm(Form10, jezik ,translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton1Click(TObject *Sender)
{
  String jezik="HR";
  	translateForm(this, jezik ,translation);
	translateForm(Aplikacija, jezik ,translation);
	translateForm(Registracija, jezik ,translation);
    translateForm(Form4, jezik ,translation);
	translateForm(Form5, jezik ,translation);
	translateForm(Form6, jezik ,translation);
	translateForm(Form7, jezik ,translation);
	translateForm(Form8, jezik ,translation);
	translateForm(Form9, jezik ,translation);
	translateForm(Form10, jezik ,translation);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
	tablica_korisnika->Close();
	tablica_korisnika->Open();
}
//---------------------------------------------------------------------------

