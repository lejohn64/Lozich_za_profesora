//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <Vcl.DBGrids.hpp>
#include <Vcl.Grids.hpp>




#include <Vcl.DBCtrls.hpp>
#include <Xml.XMLIntf.hpp>
#include <Xml.xmldom.hpp>

#include <Xml.XMLIntf.hpp>



#include "frxDBSet.hpp"
#include "frxExportBaseDialog.hpp"
#include "frxExportPDF.hpp"
#include <Xml.XMLDoc.hpp>
#include "frxExportRTF.hpp"
#include "frxClass.hpp"
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdCustomTCPServer.hpp>
#include <IdTCPClient.hpp>
#include <IdTCPConnection.hpp>
#include <IdTCPServer.hpp>
#include <IdContext.hpp>
#include <IdCmdTCPServer.hpp>
#include <Vcl.ExtCtrls.hpp>/
#include <IdTCPServer.hpp>
#include <IdTCPConnection.hpp>

#include <IdTCPServer.hpp>#include <IdTCPClient.hpp>

#include <IdTCPConnection.hpp>#
#include <IdTCPServer.hpp>include <IdCustomTCPServer.hpp>

#include <IdTCPClient.hpp>#
#include <IdTCPConnection.hpp>i
#include <IdTCPServer.hpp>nclude <IdComponent.hpp>

#include <IdCustomTCPServer.hpp>#
#include <IdTCPClient.hpp>i
#include <IdTCPConnection.hpp>n
#include <IdTCPServer.hpp>clude <Xml.XMLDoc.hpp>
#include "frxExportPDF.hpp"

#include <Xml.XMLDoc.hpp>
#include "frxExportBaseDialog.hpp"
#include "frxExportPDF.hpp"
#include "frxExportRTF.hpp"
#include <Xml.XMLDoc.hpp>
//--------------------------------------------------------------------------
class TAplikacija : public TForm
{
__published:	// IDE-managed Components
	TButton *PrikazLozinki;
	TComboBox *ComboBoxFonts;
	TEdit *ESize;
	TButton *Uredu;
	TButton *Button1;
	TDBGrid *DBGrid1;
	TADOQuery *Tablica;
	TDataSource *DataSource1;
	TfrxReport *frxReport1;
	TButton *Button2;
	TfrxDBDataset *Lozinke;
	TDataSource *DataSource2;
	TADOQuery *Tablica2;
	TButton *Button3;
	TButton *Button4;
	TfrxPDFExport *frxPDFExport1;
	TfrxRTFExport *frxRTFExport1;
	TDBImage *DBImage1;
	TButton *Button5;
	TXMLDocument *XMLDocument1;
	TButton *Button6;
	TIdTCPClient *TCP_klijent;
	TIdCmdTCPServer *IdCmdTCPServer1;
	TButton *Button7;
	TEdit *Edit1;
	TEdit *Edit2;
	TEdit *Edit3;
	TEdit *Edit4;
	TEdit *Edit5;
	TButton *Button8;
	TLabel *LNaslov;
	TLabel *LKorisnik;
	TLabel *LSifra;
	TLabel *Label4;
	TLabel *LBiljeske;
	TButton *Button9;
	TImage *Image1;
	TRadioButton *RadioButton3;
	TGroupBox *GroupBox1;
	TRadioButton *Korisnik;
	TRadioButton *Naslov;
	TGroupBox *GroupBox2;
	TRadioButton *ASC;
	TRadioButton *DESC;
	TButton *Sort;
	TGroupBox *GroupBox3;
	TRadioButton *Korisnik2;
	TRadioButton *Naslov2;
	TEdit *EFilter;
	void __fastcall UreduClick(TObject *Sender);
	void __fastcall PrikazLozinkiClick(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Button5Click(TObject *Sender);
	void __fastcall Button6Click(TObject *Sender);
	void __fastcall Button7Click(TObject *Sender);
	void __fastcall DBGrid1CellClick(TColumn *Column);
	void __fastcall Button8Click(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall Button9Click(TObject *Sender);
	void __fastcall SortClick(TObject *Sender);
	void __fastcall EFilterChange(TObject *Sender);
private:	// User declarations
UnicodeString username;

public:		// User declarations
	__fastcall TAplikacija(TComponent* Owner);
	void recieved_user(UnicodeString UserName);

};
//---------------------------------------------------------------------------
extern PACKAGE TAplikacija *Aplikacija;
//---------------------------------------------------------------------------
#endif
