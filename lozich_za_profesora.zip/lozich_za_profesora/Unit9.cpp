﻿//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
#include "Unit2.h"
#include "Unit9.h"
#include "izbrisane_lozinke.h"
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_CryptographicLibrary"
#pragma link "uTPLb_Hash"
#pragma link "uTPLb_Codec"
#pragma resource "*.dfm"
TForm9 *Form9;
//---------------------------------------------------------------------------
void TForm9::recieved_user(UnicodeString UserName){
	username = UserName;
}

__fastcall TForm9::TForm9(TComponent* Owner)
	: TForm(Owner)
{
	Pitanje->Active = True;
	Korisnici2->Active = True;

	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form9->Font->Size=fontSize;
	Form9->Font->Name=fontName;
	korisnik9->Font->Style=TFontStyles() << fsBold;
	Lozinka9->Font->Style=TFontStyles() << fsBold;
	PitanjeOdg9->Font->Style=TFontStyles() << fsBold;


	delete ini;

	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");
	reg->WriteString("EditKorisnik",".....");



	Form9->Height=reg->ReadInteger("Visina");
	Form9->Width=reg->ReadInteger("Sirina");
	Form9->Top=reg->ReadInteger("Gore");
	Form9->Left=reg->ReadInteger("Lijevo");
	Form9->Color = TColor(RGB(211,211,211 ));
	Form9->Edit1->TextHint=reg->ReadString("EditKorisnik");


	reg->CloseKey();
	}

	delete reg;
}
//---------------------------------------------------------------------------
void __fastcall TForm9::IzbrisiK9Click(TObject *Sender)
{
	if (MessageBoxW(NULL, L"Jeste li sigurni da zelite izbrisati racun? Nema povratka", L"Confirmation", MB_YESNO | MB_ICONQUESTION) == IDYES)
		{
			Korisnici2->First();
			for(int i = 0; i < Korisnici2->RecordCount; i++) {

				if (racun.getID() == Korisnici2->FieldByName("ID")->AsInteger) {
        			Korisnici2->Delete();
					break;
				}
				Korisnici2->Next();
			}

			Application->Terminate();
		}
}

//---------------------------------------------------------------------------

void __fastcall TForm9::PromijeniK9Click(TObject *Sender)
{
	_di_IXMLpasswordsType lozinke = Getpasswords(XMLDocument1);
	string korisnicko = AnsiString(Edit1->Text).c_str();
	string lozinka = AnsiString(Edit4->Text).c_str();
	Korisnik korisnik (korisnicko,lozinka,True);

   Korisnici2->First();
   for(int i=0;i<Korisnici2->RecordCount;i++)
   {
	  if (racun.getID() == Korisnici2->FieldByName("ID")->AsString) {
	  Korisnici2->Edit();
	  Korisnici2->FieldByName("Password")->AsString = korisnik.getPassword();
	  Korisnici2->FieldByName("Username")->AsString = korisnik.getUsername();
	  Korisnici2->Post();
	  break;
	  }

	  Korisnici2->Next();
   }

   	for(int i=0;i<lozinke->Count;i++){

		if(lozinke->password[i]->id == racun.getID()){
			lozinke->password[i]->Set_username(korisnicko.c_str());
		}
	}
	XMLDocument1->SaveToFile(XMLDocument1->FileName);

		TCP_klijent->Host = "127.0.0.1";
		TCP_klijent->Port = 6969;
		TCP_klijent->Connect();
		TCP_klijent->IOHandler->WriteLn("Dodaj");


		std::unique_ptr<TFileStream> fs(new TFileStream(XMLDocument1->FileName, fmOpenRead));
		TCP_klijent->Socket->WriteLn(ExtractFileName(fs->FileName));
		TCP_klijent->Socket->Write(fs->Size);
		TCP_klijent->Socket->Write(fs.get());

	  TCP_klijent->Disconnect();



	 std::unique_ptr<TStringStream> jsonStream(new TStringStream);
	jsonStream->LoadFromFile("login_log.json");

	// create JSON object that represents entire JSON file
	TJSONObject* jsonFile = (TJSONObject*)TJSONObject::ParseJSONValue(jsonStream->DataString);

	// create JSON object that represent array from inside addresBook object
	TJSONArray* contactsArray = (TJSONArray*)TJSONObject::ParseJSONValue(jsonFile->GetValue("logins")->ToString());

	// read and output each address book contact
	String jsonDoc;
	jsonDoc = "{";
		jsonDoc += "\"logins\":";
		jsonDoc += "[";
	for (int i = contactsArray->Count - 1; i >= 0; i--) {

		// read contact info
		UnicodeString user = contactsArray->Items[i]->GetValue<UnicodeString>("user");
		UnicodeString login_attempt = contactsArray->Items[i]->GetValue<UnicodeString>("login_attempt");
		UnicodeString time =	contactsArray->Items[i]->GetValue<UnicodeString>("time");


		Codec1->Password="kljuc";
		String decodedUser;
		Codec1->DecryptString(decodedUser, user,TEncoding::UTF8);

		String kriptirani_user;
		Codec1->EncryptString(UnicodeString(korisnik.getUsername()).c_str(), kriptirani_user,TEncoding::UTF8);

		if(i>0){
			if(username.Compare(decodedUser)!= 0)
			{
			jsonDoc +=
				"{"
					"\"user\":\"" + user + "\"," +
					"\"login_attempt\":\"" + login_attempt  + "\"," +
					"\"time\":\"" + time + "\"" +
				"},";
			}
			else{
			jsonDoc +=
				"{"
					"\"user\":\"" + kriptirani_user + "\"," +
					"\"login_attempt\":\"" + login_attempt  + "\"," +
					"\"time\":\"" + time + "\"" +
				"},";
			}
		}
		else{
		if(username.Compare(decodedUser)!= 0)
			{
			jsonDoc +=
				"{"
					"\"user\":\"" + user + "\"," +
					"\"login_attempt\":\"" +login_attempt  + "\"," +
					"\"time\":\"" + time + "\"" +
				"}";
			}
			else{
			jsonDoc +=
				"{"
					"\"user\":\"" + kriptirani_user + "\"," +
					"\"login_attempt\":\"" + login_attempt  + "\"," +
					"\"time\":\"" + time + "\"" +
				"}";
			}
        }


	}
			jsonDoc += "]}";
	std::unique_ptr<TStringStream> ss(new TStringStream);
	ss->WriteString(jsonDoc);
	ss->SaveToFile("login_log.json");

}
//---------------------------------------------------------------------------

void __fastcall TForm9::PromijeniP9Click(TObject *Sender)
{
	UnicodeString pitanje = Edit3->Text;
	UnicodeString odgovor = Edit2->Text;
	bool pitanjePostoji = false;


	if(pitanje != ""){
		Pitanje->First();
		for(int i = 0; i < Pitanje->RecordCount; i++) {


			if (racun.getID() == Pitanje->FieldByName("UserID")->AsInteger) {
				Pitanje->Edit();
				Pitanje->FieldByName("Pitanje")->AsString = pitanje;
				Pitanje->FieldByName("Odgovor")->AsString = odgovor;
				Pitanje->Post();
				pitanjePostoji = true;
				break;
			}


			Pitanje->Next();
		}

		if(pitanjePostoji== false){
            Pitanje->Append();
				Pitanje->FieldByName("UserID")->AsString = racun.getID();
				Pitanje->FieldByName("Pitanje")->AsString = Edit3->Text;
				Pitanje->FieldByName("Odgovor")->AsString = Edit2->Text;
			Pitanje->Post();
		}
	}
	else{
        ShowMessage("Unesite pitanje!");
    }

}
//---------------------------------------------------------------------------


void __fastcall TForm9::IzbrisiPClick(TObject *Sender)
{
	if (MessageBoxW(NULL, L"Želite li izbrisati odgovor? Resetiranje lozinke će vam postati nesigurno", L"Confirmation", MB_YESNO | MB_ICONQUESTION) == IDYES){
		Pitanje->First();
		for(int i = 0; i < Pitanje->RecordCount; i++) {
			if (racun.getID() == Pitanje->FieldByName("UserID")->AsInteger) {
					Pitanje->Delete();
				break;
			}
			Pitanje->Next();
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm9::Nazad9Click(TObject *Sender)
{
	Hide();
    Aplikacija->Show();
}
//---------------------------------------------------------------------------


void __fastcall TForm9::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------

