//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit6.h"
#include "Unit1.h"
#include "Unit2.h"
#include "Unit7.h"
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm6 *Form6;
//---------------------------------------------------------------------------
UnicodeString GlobalURL;
bool ikona_present=false;
__fastcall TForm6::TForm6(TComponent* Owner)
	: TForm(Owner)
{
	Racun->Active = True;

	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form6->Font->Size=fontSize;
	Form6->Font->Name=fontName;
	LNaslov->Font->Style=TFontStyles() << fsBold;
	LKorisnik->Font->Style=TFontStyles() << fsBold;
	LSifra->Font->Style=TFontStyles() << fsBold;
	LURL->Font->Style=TFontStyles() << fsBold;
	LBiljeske->Font->Style=TFontStyles() << fsBold;

	delete ini;

	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");
	reg->WriteBool("Check",false);


	Form6->Height=reg->ReadInteger("Visina");
	Form6->Width=reg->ReadInteger("Sirina");
	Form6->Top=reg->ReadInteger("Gore");
	Form6->Left=reg->ReadInteger("Lijevo");
	Form6->Color = TColor(RGB(211,211,211 ));
	Form6->CheckBox1->Checked=reg->ReadBool("Check");



	reg->CloseKey();
	}

	delete reg;
}
//---------------------------------------------------------------------------
void __fastcall TForm6::BGenerirajClick(TObject *Sender)
{
	LozinkaGen loz;
	AnsiString combinedChar = "";
	AnsiString specChar = "!@#$%^&*-+~=|\\/:;\"'<>,.?[]{}()";
	AnsiString numbers = "0123456789";
	AnsiString sChar = "abcdefghijklmnopqrstuvwxyz";
	AnsiString bChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	AnsiString space = "        ";

	if (CheckBox1->Checked) {
		combinedChar += bChar;
	}

	if (CheckBox2->Checked) {
		combinedChar += sChar;
	}

	if (CheckBox3->Checked) {
		combinedChar += numbers;
	}

	if (CheckBox4->Checked) {
		combinedChar += space;
	}

	if (CheckBox5->Checked) {
		combinedChar += specChar;
	}

	Lozinka->Text = loz.GenerirajLozinku(NumberBox1->Text.ToInt(), combinedChar.c_str());
}
//---------------------------------------------------------------------------




void __fastcall TForm6::BZapisClick(TObject *Sender)
{
	LozinkaGen Acc;

	if(Naslov->Text	 != ""){
		Acc.SetNaziv(Naslov->Text);
	}

	if(URL->Text !=""){
		Acc.SetURL(URL->Text);
		Acc.SetPrisutna_ikona(True);
	}
	if(Biljeska->Text !=""){
		Acc.SetBiljeska(Biljeska->Text);
	}

	if(Korisnicko->Text != "" && Lozinka->Text.Length() > 8 ){
		Acc.SetKorisnicko(Korisnicko->Text);
		Acc.SetLozinka(Lozinka->Text);
		Acc.Posalji_u_bazu(Racun);
		Hide();
		Aplikacija->Show();
	}
	else{
		ShowMessage("Ispravno postavite korisnicko ime i lozinku!");
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm6::BPovratakClick(TObject *Sender)
{
	Hide();
	Aplikacija->Show();
    ikona_present=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm6::GenIkonaClick(TObject *Sender)
{
	GlobalURL = URL->Text;
	Hide();
	Form7->Show();
}
//---------------------------------------------------------------------------


void __fastcall TForm6::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------


