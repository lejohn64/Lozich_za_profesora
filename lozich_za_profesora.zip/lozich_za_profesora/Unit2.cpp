//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
#include "Unit1.h"
#include "Unit6.h"
#include "Unit8.h"
#include "Unit9.h"
#include "Unit10.h"
#include "izbrisane_lozinke.h"
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)


#pragma link "frxClass"
#pragma link "frxDBSet"
#pragma link "frxExportBaseDialog"
#pragma link "frxExportPDF"
#pragma link "frxExportRTF"

#pragma link "frxDBSet"
#pragma link "frxExportBaseDialog"
#pragma link "frxExportPDF"
#pragma link "frxExportBaseDialog"
#pragma link "frxExportPDF"
#pragma link "frxExportPDF"
#pragma link "frxExportRTF"
#pragma link "frxClass"
#pragma resource "*.dfm"


TAplikacija *Aplikacija;

void TAplikacija::recieved_user(UnicodeString UserName){
	username = UserName;
}


//---------------------------------------------------------------------------
__fastcall TAplikacija::TAplikacija(TComponent* Owner)
	: TForm(Owner)
{
	DBImage1->DoubleBuffered = true;
    HINSTANCE RecourceDll;

	if ((RecourceDll = LoadLibrary(L"Logotip.dll")) == NULL) {
		ShowMessage("Can't load DLL");
		return;
	}
	TResourceStream* rs = new TResourceStream((int)RecourceDll, "LOGO", RT_RCDATA);
	Image1->Picture->LoadFromStream(rs);
    delete rs;
	FreeLibrary(RecourceDll);

	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Aplikacija->Font->Size=fontSize;
	Aplikacija->Font->Name=fontName;
	LNaslov->Font->Style=TFontStyles() << fsBold;
	LKorisnik->Font->Style=TFontStyles() << fsBold;
	LSifra->Font->Style=TFontStyles() << fsBold;
	Label4->Font->Style=TFontStyles() << fsBold;
	LBiljeske->Font->Style=TFontStyles() << fsBold;





	delete ini;



	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",1200);
	reg->WriteString("Background","Gray");

	reg->WriteInteger("FontSize",10);
	reg->WriteString("FilterPolje","Matija");

	Aplikacija->Height=reg->ReadInteger("Visina");
	Aplikacija->Width=reg->ReadInteger("Sirina");
	Aplikacija->Top=reg->ReadInteger("Gore");
	Aplikacija->Left=reg->ReadInteger("Lijevo");
	Aplikacija->Color = TColor(RGB(211,211,211 ));

	Aplikacija->ESize->Text=reg->ReadInteger("FontSize");
	Aplikacija->EFilter->TextHint=reg->ReadString("FilterPolje");

	reg->CloseKey();
	}

	delete reg;

}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------

void __fastcall TAplikacija::UreduClick(TObject *Sender)
{
 TIniFile* ini = new TIniFile(GetCurrentDir()+"settings2.ini");
 AnsiString fontName;
if (ComboBoxFonts->Text =="Arial") {
		DBGrid1->Font->Name = ini->ReadString("GridFont","Name","Arial");
 }
 else if(ComboBoxFonts->Text =="Times New Roman"){
		DBGrid1->Font->Name = ini->ReadString("GridFont","Name","Times New Roman");
 }
  else {
	DBGrid1->Font->Name = ini->ReadString("GridFont","Name","Calibri");
  }


 if(ESize->Text.IsEmpty()){
	 DBGrid1->Font->Size =ini->ReadInteger("Font", "Size",10);;
 }
 else{
 DBGrid1->Font->Size = ESize->Text.ToInt();

 };
 delete ini;

}
//---------------------------------------------------------------------------
void __fastcall TAplikacija::PrikazLozinkiClick(TObject *Sender)
{
	Tablica->Close();
	Tablica->SQL->Clear();
	Tablica->SQL->Add("SELECT * FROM Upit1 WHERE UserID = :UserID");
	Tablica->Parameters->ParamByName("UserID")->Value = racun.getID();
	Tablica->Open();
}
//---------------------------------------------------------------------------

void __fastcall TAplikacija::Button1Click(TObject *Sender)
{
	Hide();
	Form6->Show();
}
//---------------------------------------------------------------------------

void __fastcall TAplikacija::Button2Click(TObject *Sender)
{
	Tablica2->Close();
	Tablica2->SQL->Clear();
	Tablica2->SQL->Add("SELECT * FROM Upit1 WHERE UserID = :UserID");
	Tablica2->Parameters->ParamByName("UserID")->Value = racun.getID();
	Tablica2->Open();
	frxReport1->ShowReport();

}
//---------------------------------------------------------------------------

void __fastcall TAplikacija::Button3Click(TObject *Sender)
{
	Tablica2->Close();
	Tablica2->SQL->Clear();
	Tablica2->SQL->Add("SELECT * FROM Upit1 WHERE UserID = :UserID");
	Tablica2->Parameters->ParamByName("UserID")->Value = racun.getID();
	Tablica2->Open();

	frxReport1->PrepareReport(true);
	frxReport1->FileName = "Lozinke.pdf";
	frxReport1->Export(frxPDFExport1);
}
//---------------------------------------------------------------------------

void __fastcall TAplikacija::Button4Click(TObject *Sender)
{
	Tablica2->Close();
	Tablica2->SQL->Clear();
	Tablica2->SQL->Add("SELECT * FROM Upit1 WHERE UserID = :UserID");
	Tablica2->Parameters->ParamByName("UserID")->Value = racun.getID();
	Tablica2->Open();

	frxReport1->PrepareReport(true);
	frxReport1->FileName = "Lozinke.rtf";
	frxReport1->Export(frxRTFExport1);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void __fastcall TAplikacija::Button5Click(TObject *Sender)
{
	XMLDocument1->Active = true;

	if (DBGrid1->DataSource != NULL && DBGrid1->DataSource->DataSet != NULL){
			TDataSet* dataset = DBGrid1->DataSource->DataSet;
			if (!dataset->IsEmpty() && !dataset->Bof)
			{

				_di_IXMLpasswordsType lozinke = Getpasswords(XMLDocument1);
				_di_IXMLpasswordType lozinka = lozinke->Add();

				lozinka->id = dataset->FieldByName("UserID")->AsInteger;
				lozinka->master_username = racun.getUsername();
				lozinka->title = dataset->FieldByName("Title")->AsString;
				lozinka->username = dataset->FieldByName("Username")->AsString;
				lozinka->password = dataset->FieldByName("Password")->AsString;
				lozinka->timestamp = dataset->FieldByName("Timestamp")->AsString;

				XMLDocument1->SaveToFile(XMLDocument1->FileName);
		  }
		dataset->Delete();
	}
   //	XMLDocument1->Active = false;



		TCP_klijent->Host = "127.0.0.1";
		TCP_klijent->Port = 6969;
		TCP_klijent->Connect();
		TCP_klijent->IOHandler->WriteLn("Dodaj");


		std::unique_ptr<TFileStream> fs(new TFileStream(XMLDocument1->FileName, fmOpenRead));
		TCP_klijent->Socket->WriteLn(ExtractFileName(fs->FileName));
		TCP_klijent->Socket->Write(fs->Size);
		TCP_klijent->Socket->Write(fs.get());

	  TCP_klijent->Disconnect();

}

void __fastcall TAplikacija::Button6Click(TObject *Sender)
{
	Hide();
	Form8->Show();
}
//---------------------------------------------------------------------------


void __fastcall TAplikacija::Button7Click(TObject *Sender)
{
	Hide();
    Form9->Show();
}
//---------------------------------------------------------------------------

void __fastcall TAplikacija::DBGrid1CellClick(TColumn *Column)
{
	Edit1->Text=DBGrid1->DataSource->DataSet->FieldByName("Title")->AsString;
	Edit2->Text=DBGrid1->DataSource->DataSet->FieldByName("Username")->AsString;
	Edit3->Text=DBGrid1->DataSource->DataSet->FieldByName("Password")->AsString;
	Edit4->Text=DBGrid1->DataSource->DataSet->FieldByName("URL")->AsString;
}
//---------------------------------------------------------------------------

void __fastcall TAplikacija::Button8Click(TObject *Sender)
{
	  Tablica->Edit();
	  DBGrid1->DataSource->DataSet->FieldByName("Title")->AsString=Edit1->Text;
	  DBGrid1->DataSource->DataSet->FieldByName("Username")->AsString=Edit2->Text;
	  DBGrid1->DataSource->DataSet->FieldByName("Password")->AsString=Edit3->Text;
	  DBGrid1->DataSource->DataSet->FieldByName("URL")->AsString=Edit4->Text;
	  DBGrid1->DataSource->DataSet->FieldByName("Notes")->AsString=Edit5->Text;
	  Tablica->Post();
}
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
void __fastcall TAplikacija::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------

void __fastcall TAplikacija::Button9Click(TObject *Sender)
{
	Hide();
	Form10->Show();
}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

void __fastcall TAplikacija::SortClick(TObject *Sender)
{
   if(Naslov->Checked){
   if(ASC->Checked){
   UnicodeString sql2 = "SELECT * FROM Upit1 WHERE UserID = " + racun.getID()+ "  ORDER BY Title ASC";
   Tablica->SQL->Text=sql2;
   Tablica->Active="True";
   }
   else{
   UnicodeString sql2 = "SELECT * FROM Upit1 WHERE UserID = " + racun.getID()+ "  ORDER BY Title DESC";
   Tablica->SQL->Text=sql2;
   Tablica->Active="True";
   }
   }
  else{
  if(ASC->Checked){
   UnicodeString sql2 = "SELECT * FROM Upit1 WHERE UserID = " + racun.getID()+ "  ORDER BY Username ASC";
   Tablica->SQL->Text=sql2;
   Tablica->Active="True";
   }
   else{
   UnicodeString sql2 = "SELECT * FROM Upit1 WHERE UserID = " + racun.getID()+ "  ORDER BY Username DESC";
   Tablica->SQL->Text=sql2;
   Tablica->Active="True";
   }
   }

}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

void __fastcall TAplikacija::EFilterChange(TObject *Sender)
{
   if(Korisnik2->Checked){
   UnicodeString sql2 = "SELECT * FROM Upit1 WHERE UserID = " + racun.getID()+ " AND Username ='"+EFilter->Text+"'";
   Tablica->SQL->Text=sql2;
   Tablica->Active="True";
   }
   else{
   UnicodeString sql2 = "SELECT * FROM Upit1 WHERE UserID = " + racun.getID()+ " AND Title='"+ EFilter->Text+"'";
   Tablica->SQL->Text=sql2;
   Tablica->Active="True";
   }
}
//---------------------------------------------------------------------------

