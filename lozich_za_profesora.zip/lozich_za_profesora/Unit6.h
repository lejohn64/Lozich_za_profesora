//---------------------------------------------------------------------------

#ifndef Unit6H
#define Unit6H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.NumberBox.hpp>
#include <Data.DB.hpp>
#include <Data.FMTBcd.hpp>
#include <Data.SqlExpr.hpp>
#include <Data.Win.ADODB.hpp>
#include <Unit1.h>
#include <Vcl.Dialogs.hpp>
extern UnicodeString GlobalURL;
//---------------------------------------------------------------------------
class TForm6 : public TForm
{
__published:	// IDE-managed Components
	TEdit *Naslov;
	TLabel *LKorisnik;
	TEdit *Korisnicko;
	TLabel *LSifra;
	TEdit *Lozinka;
	TLabel *LURL;
	TEdit *URL;
	TLabel *LBiljeske;
	TEdit *Biljeska;
	TButton *BZapis;
	TButton *BPovratak;
	TButton *GenIkona;
	TButton *BGeneriraj;
	TCheckBox *CheckBox1;
	TCheckBox *CheckBox2;
	TCheckBox *CheckBox3;
	TCheckBox *CheckBox4;
	TCheckBox *CheckBox5;
	TNumberBox *NumberBox1;
	TLabel *LLozinkaP;
	TADOTable *Racun;
	TOpenDialog *OpenDialog1;
	TLabel *LNaslov;
	void __fastcall BGenerirajClick(TObject *Sender);
	void __fastcall BZapisClick(TObject *Sender);
	void __fastcall BPovratakClick(TObject *Sender);
	void __fastcall GenIkonaClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
public:		// User declarations
	__fastcall TForm6(TComponent* Owner);
};
//---------------------------------------------------------------------------
class LozinkaGen {
private:
	AnsiString Naziv;
	AnsiString Korisnicko;
	AnsiString Lozinka;
	AnsiString URL;
	AnsiString Biljeska;
	AnsiString Ikona;
	int Duljina;
	bool Prisutna_ikona = false;

public:

	LozinkaGen() {
		Naziv = "";
		Korisnicko = "";
		Lozinka = "";
        URL = "";
        Biljeska = "";
		Ikona = "";
		Duljina = 0;
	}

    AnsiString GetNaziv() const {
        return Naziv;
    }

    AnsiString GetKorisnicko() const {
        return Korisnicko;
    }

    AnsiString GetLozinka() const {
        return Lozinka;
    }

    AnsiString GetURL() const {
        return URL;
    }

    AnsiString GetBiljeska() const {
        return Biljeska;
    }

    int GetDuljina() const {
        return Duljina;
    }

    void SetNaziv(AnsiString _Naziv) {
        Naziv = _Naziv;
    }

    void SetKorisnicko(AnsiString _Korisnicko) {
        Korisnicko = _Korisnicko;
    }

    void SetLozinka(AnsiString _Lozinka) {
        Lozinka = _Lozinka;
    }

    void SetURL(AnsiString _URL) {
		URL = _URL;
    }

    void SetBiljeska(AnsiString _Biljeska) {
        Biljeska = _Biljeska;
	}

    void SetDuljina(int _Duljina) {
		Duljina = _Duljina;
    }

	void SetPrisutna_ikona(bool _Prisutna_ikona) {
        Prisutna_ikona = _Prisutna_ikona;
	}

	AnsiString GenerirajLozinku(int _Duljina, AnsiString _Svi_char) {
	int br_char = _Svi_char.Length();
	AnsiString lozinka="";

		for (int i = 0; i < _Duljina; i++) {
			Randomize();
			lozinka += _Svi_char[Random(br_char) + 1];
		}

	return lozinka;
	}

	void Posalji_u_bazu(TADOTable* Racun){

	 Racun->First();		//provjera korisnika u bazi za registraciju
	 Racun->Append();
	 Racun->FieldByName("UserID")->AsString = racun.getID();
	 static_cast <TBlobField*> (Racun->FieldByName("Icon"))->LoadFromFile("favicon.ico");
	 Racun->FieldByName("Title")->AsString = Naziv;
	 Racun->FieldByName("Username")->AsString =   Korisnicko;
	 Racun->FieldByName("Password")->AsString =   Lozinka;
	 Racun->FieldByName("URL")->AsString =   URL;
	 Racun->FieldByName("Notes")->AsString =   Biljeska;
	 Racun->FieldByName("Timestamp")->AsString = DateTimeToStr(Now());
	 Racun->Post();
	}
};
extern PACKAGE TForm6 *Form6;
//---------------------------------------------------------------------------
#endif
