//---------------------------------------------------------------------------

#ifndef Uint1H
#define Uint1H
extern int UserId;
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <uTPLb_Hash.hpp>
#include <uTPLb_BaseNonVisualComponent.hpp>
#include <uTPLb_CryptographicLibrary.hpp>
#include <uTPLb_StreamUtils.hpp>
#include <idhashmessagedigest.hpp>
#include <IdHashSHA.hpp>
#include <Idsslopenssl.hpp>
#include <Data.Bind.Components.hpp>
#include <Data.Bind.ObjectScope.hpp>
#include <REST.Client.hpp>
#include <REST.Types.hpp>
#include "uTPLb_Codec.hpp"
#include <System.SysUtils.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <random>
#include <ctime>
#include <string>
#include <REST.Client.hpp>
#include <System.JSON.hpp>
#include <System.IOUtils.hpp>
#include "User_i_ID.h"
#include  <map>
std::map<String, std::map<String,String>> translation;
using namespace std;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *Prijava;
	TEdit *EditKorisnicko;
	TEdit *EditLozinka;
	TLabel *Label1;
	TLabel *Label2;
	TButton *otvori_reg;
	TADOConnection *ADOConnection1;
	TADOTable *tablica_korisnika;
	TCheckBox *PrikazLozinke;
	THash *Hash1;
	TCryptographicLibrary *CryptographicLibrary1;
	TRESTClient *RESTClient1;
	TLabel *Label3;
	TCodec *Codec1;
	TImage *Image1;
	TRadioButton *RadioButton1;
	TRadioButton *RadioButton2;

	void __fastcall PrijavaClick(TObject *Sender);
	void __fastcall otvori_regClick(TObject *Sender);
	void __fastcall PrikazLozinkeClick(TObject *Sender);
	void __fastcall Label3Click(TObject *Sender);
	void __fastcall RadioButton2Click(TObject *Sender);
	void __fastcall RadioButton1Click(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
extern   UsernameID racun;

static const char characters[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";


 class Korisnik{
	 private:
	 string  username;
	 string  password;
	 string  old_password;
	 UnicodeString passwordScore;
	 UnicodeString passwordTip;

	 public:

	 Korisnik (string  _username, string  _password, bool imasol){

		if(imasol){
			username = _username;
			old_password = _password;
			password = generirajSol
			 (_password, _username);
		}

		else{
			username = _username;
			password = _password;
		}
	 }

	UnicodeString getUsername() const {
		return username.c_str()	;
	}

	UnicodeString getPassword() const {
		return password.c_str()	;
	}

	UnicodeString GetPasswordScore() {
		if(passwordScore == "") {
			fetchPasswordCheckResults();
		}
		return passwordScore;
	}

	UnicodeString GetPasswordTip() {
		if(passwordTip == "") {
			fetchPasswordCheckResults();
		}
		return passwordTip;
	}

 	AnsiString dobiSol() const{
		TIdHashMessageDigest*   MD5 = new TIdHashMessageDigest5;
		TIdHashSHA1* sha1 = new TIdHashSHA1;
		AnsiString combine= NULL;

		combine = MD5->HashStringAsHex(AnsiString(username.c_str()) + " deanathematize polyporaceous prewashes ");

		return combine;

	}

	 char getRandomChar() {
		static const int length = sizeof(characters) - 1;

		random_device rd;
		mt19937 gen(rd());
		uniform_int_distribution<> dis(0, length - 1);

		return characters[dis(gen)];
	 }

	 AnsiString generirajSol(string password, string username){
		TIdHashMessageDigest*   MD5 = new TIdHashMessageDigest5;
		TIdHashSHA1* sha1 = new TIdHashSHA1;
		AnsiString combine= NULL;

		//soljenje
		combine = MD5->HashStringAsHex(AnsiString(username.c_str()) + " deanathematize polyporaceous prewashes ");

		//paprenje
		combine = sha1->HashStringAsHex(AnsiString(combine.c_str()) + AnsiString(password.c_str()) + getRandomChar());

		return combine;

	 }

	void fetchPasswordCheckResults() {
		TRESTClient* client = new TRESTClient(NULL);
		TRESTRequest* request = new TRESTRequest(NULL);
		TRESTResponse* response = new TRESTResponse(NULL);



			client->BaseURL = "http://localhost:3000";

			request->Client = client;
			request->Response = response;
			request->Resource = "passwordCheck";
			request->Method = rmPOST;

			TJSONObject* json = new TJSONObject;
			json->AddPair("username", UnicodeString(username.c_str()));
			json->AddPair("password", UnicodeString(old_password.c_str()));

			request->AddBody(json->ToString(), ctAPPLICATION_JSON);

			request->Execute();

			if (response->StatusCode == 200) {
				UnicodeString content = response->Content;

				TJSONObject* jsonResponse = dynamic_cast<TJSONObject*>(TJSONObject::ParseJSONValue(content));

				passwordScore = jsonResponse->GetValue("score")->ToString();
				passwordTip = jsonResponse->GetValue("suggestions")->ToString();
			}


		delete request;
		delete client;
		delete response;
	}

 };



//---------------------------------------------------------------------------

#endif
