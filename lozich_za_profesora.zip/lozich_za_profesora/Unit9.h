//---------------------------------------------------------------------------

#ifndef Unit9H
#define Unit9H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Data.DB.hpp>
#include <Data.Win.ADODB.hpp>
#include <uTPLb_Hash.hpp>
#include <uTPLb_BaseNonVisualComponent.hpp>
#include <uTPLb_CryptographicLibrary.hpp>
#include <uTPLb_StreamUtils.hpp>
#include <idhashmessagedigest.hpp>
#include <IdHashSHA.hpp>
#include <Idsslopenssl.hpp>
#include <Data.Bind.Components.hpp>
#include <Data.Bind.ObjectScope.hpp>
#include <REST.Client.hpp>
#include <REST.Types.hpp>
#include <Xml.XMLDoc.hpp>
#include <Xml.xmldom.hpp>
#include <Xml.XMLIntf.hpp>
#include <IdBaseComponent.hpp>
#include <IdComponent.hpp>
#include <IdTCPClient.hpp>
#include <IdTCPConnection.hpp>
#include "uTPLb_Codec.hpp"
#include <System.SysUtils.hpp>
#include <random>
#include <ctime>
#include <string>
#include <REST.Client.hpp>
#include <System.JSON.hpp>
#include <System.IOUtils.hpp>
//---------------------------------------------------------------------------
class TForm9 : public TForm
{
__published:	// IDE-managed Components
	TLabel *korisnik9;
	TEdit *Edit1;
	TButton *PromijeniK9;
	TLabel *PitanjeOdg9;
	TEdit *Edit2;
	TButton *PromijeniP9;
	TLabel *Label4;
	TButton *IzbrisiP;
	TButton *Nazad9;
	TButton *IzbrisiK9;
	TADOTable *Pitanje;
	TADOTable *Korisnici2;
	TEdit *Edit3;
	TEdit *Edit4;
	TLabel *Lozinka9;
	TXMLDocument *XMLDocument1;
	TIdTCPClient *TCP_klijent;
	TCodec *Codec1;
	void __fastcall IzbrisiK9Click(TObject *Sender);
	void __fastcall PromijeniK9Click(TObject *Sender);
	void __fastcall PromijeniP9Click(TObject *Sender);
	void __fastcall IzbrisiPClick(TObject *Sender);
	void __fastcall Nazad9Click(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
UnicodeString username;
public:		// User declarations
	__fastcall TForm9(TComponent* Owner);
	void recieved_user(UnicodeString UserName);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm9 *Form9;
//---------------------------------------------------------------------------

#endif
