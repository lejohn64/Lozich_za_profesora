//---------------------------------------------------------------------------

#include <vcl.h>
#include "Unit2.h"
#include "Unit1.h"
#include <System.JSON.hpp>
#pragma hdrstop

#include "Unit10.h"
#include "Unit1.h"
#include <registry.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "uTPLb_BaseNonVisualComponent"
#pragma link "uTPLb_Codec"
#pragma link "uTPLb_CryptographicLibrary"
#pragma resource "*.dfm"
using namespace std;
TForm10 *Form10;

//---------------------------------------------------------------------------
__fastcall TForm10::TForm10(TComponent* Owner)
	: TForm(Owner)
{
	TIniFile* ini = new TIniFile(GetCurrentDir()+"\\settings.ini");
	ini->WriteString("Font", "Name", "Arial");
	ini->WriteInteger("Font", "Size", 8);
	ini->WriteBool("Font", "Bold", true);

	AnsiString fontName = ini->ReadString("Font", "Name", "Arial");
	int fontSize = ini->ReadInteger("Font", "Size",8);
	bool bold =ini->ReadBool("Font", "Bold", true);

	//prijava
	Form10->Font->Size=fontSize;
	Form10->Font->Name=fontName;


	delete ini;

    	TRegistry* reg = new TRegistry;
	reg->RootKey = HKEY_LOCAL_MACHINE;
	UnicodeString kljuc="Software\\Sett";
	reg->CreateKey(kljuc);

	if(reg->OpenKey(kljuc,true)){

	reg->WriteInteger("Gore",250);
	reg->WriteInteger("Lijevo",400);
	reg->WriteInteger("Visina",600);
	reg->WriteInteger("Sirina",800);
	reg->WriteString("Background","Gray");



	Form10->Height=reg->ReadInteger("Visina");
	Form10->Width=reg->ReadInteger("Sirina");
	Form10->Top=reg->ReadInteger("Gore");
	Form10->Left=reg->ReadInteger("Lijevo");
	Form10->Color = TColor(RGB(211,211,211 ));


	reg->CloseKey();
	}

	delete reg;
}
//---------------------------------------------------------------------------
void __fastcall TForm10::Povratak10Click(TObject *Sender)
{
	Hide();
    Aplikacija->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm10::Prikaz10Click(TObject *Sender)
{
  	// load json file
	std::unique_ptr<TStringStream> jsonStream(new TStringStream);
	jsonStream->LoadFromFile("login_log.json");

	// create JSON object that represents entire JSON file
	TJSONObject* jsonFile = (TJSONObject*)TJSONObject::ParseJSONValue(jsonStream->DataString);

	// create JSON object that represent array from inside addresBook object
	TJSONArray* contactsArray = (TJSONArray*)TJSONObject::ParseJSONValue(jsonFile->GetValue("logins")->ToString());

	// read and output each address book contact
	ListView1->Items->Clear();
	int j=0;
	for (int i = 0; i < contactsArray->Count; i++) {

		// read contact info
		UnicodeString user = contactsArray->Items[i]->GetValue<UnicodeString>("user");
		UnicodeString attempt = contactsArray->Items[i]->GetValue<UnicodeString>("login_attempt");
		UnicodeString time =  contactsArray->Items[i]->GetValue<UnicodeString>("time");


		Codec1->Password="kljuc";
		UnicodeString decodedUser,decodedLogin,decodedTime;
		Codec1->DecryptString(decodedUser, user,TEncoding::UTF8);
		Codec1->DecryptString(decodedLogin,attempt,TEncoding::UTF8);
		Codec1->DecryptString(decodedTime,time ,TEncoding::UTF8);

		if(racun.getUsername().Compare(decodedUser)== 0)
		{
			// show contact info inside ListView component
			ListView1->Items->Add();
			ListView1->Items->Item[j]->Caption = decodedUser;
			ListView1->Items->Item[j]->SubItems->Add(decodedLogin);
			ListView1->Items->Item[j]->SubItems->Add(decodedTime);
			j++;
		}


	}
}

//---------------------------------------------------------------------------

void __fastcall TForm10::FormClose(TObject *Sender, TCloseAction &Action)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------


void __fastcall TForm10::Delete10Click(TObject *Sender)
{
	 std::unique_ptr<TStringStream> jsonStream(new TStringStream);
	jsonStream->LoadFromFile("login_log.json");

	// create JSON object that represents entire JSON file
	TJSONObject* jsonFile = (TJSONObject*)TJSONObject::ParseJSONValue(jsonStream->DataString);

	// create JSON object that represent array from inside addresBook object
	TJSONArray* contactsArray = (TJSONArray*)TJSONObject::ParseJSONValue(jsonFile->GetValue("logins")->ToString());

	// read and output each address book contact
	ListView1->Items->Clear();
	String jsonDoc;
	jsonDoc = "{";
		jsonDoc += "\"logins\":";
		jsonDoc += "[";
	for (int i = contactsArray->Count - 1; i >= 0; i--) {

		// read contact info
		UnicodeString user = contactsArray->Items[i]->GetValue<UnicodeString>("user");
		UnicodeString login_attempt = contactsArray->Items[i]->GetValue<UnicodeString>("login_attempt");
		UnicodeString time =	contactsArray->Items[i]->GetValue<UnicodeString>("time");


		Codec1->Password="kljuc";
		String decodedUser;
		Codec1->DecryptString(decodedUser, user,TEncoding::UTF8);

		if(i>0){
			if(racun.getUsername().Compare(decodedUser)!= 0)
			{
			jsonDoc +=
				"{"
					"\"user\":\"" + user + "\"," +
					"\"login_attempt\":\"" + login_attempt  + "\"," +
					"\"time\":\"" + time + "\"" +
				"},";
			}
		}


		else{
		if(racun.getUsername().Compare(decodedUser)!= 0)
			{
			jsonDoc +=
				"{"
					"\"user\":\"" + user + "\"," +
					"\"login_attempt\":\"" +login_attempt  + "\"," +
					"\"time\":\"" + time + "\"" +
				"}";
			}
        }


	}
			jsonDoc += "]}";
	std::unique_ptr<TStringStream> ss(new TStringStream);
	ss->WriteString(jsonDoc);
	ss->SaveToFile("login_log.json");
}
//---------------------------------------------------------------------------

