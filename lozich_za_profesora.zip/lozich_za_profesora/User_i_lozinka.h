#include <System.Classes.hpp>


using namespace std;
class UsernameID{
	private:
	UnicodeString Username;
	UnicodeString ID;

	public:
	UsernameID(){}
	UsernameID(UnicodeString _Username, UnicodeString _ID):Username(_Username), ID(_ID) {}

	UnicodeString getID();

	UnicodeString getUsername();

	void setID(UnicodeString ID);

	void setUsername(UnicodeString username);

};
